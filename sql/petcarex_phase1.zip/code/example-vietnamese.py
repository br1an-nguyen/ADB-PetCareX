# In các số chẵn trong đoạn [1, 10]

for i in range(1, 11):
    if i % 2 == 0:
        print(i)